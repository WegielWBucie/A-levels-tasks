#include <iostream>
#include <fstream>
#include <cmath>
#include <string>

using namespace std;


bool primeFromRange(int number, int lowerBound, int upperBound) {

    if(number < lowerBound || number > upperBound || number < 2) {
        return false;
    }
    if(number == 2) {
        return true;
    }
    if(number % 2 == 0) {
        return false;
    }

    for(int i = 3; i <= sqrt(number); i += 2) {

        if(number % i == 0) {
            return false;
        }

    }

    return true;
}


bool primeFromBehind(int number) {

    int numberFromBehind = 0;

    while(number > 0) {
        numberFromBehind = 10 * numberFromBehind + number % 10;
        number /= 10;
    }

    return primeFromRange(numberFromBehind, numberFromBehind, numberFromBehind);

}


int weight(int number) {

    if(number > 9) {
        int numbersSum = 0;
            while(number > 0) {
            numbersSum += number % 10;
            number /= 10;
        }
        return weight(numbersSum);
    }
    else {
        return number;
    }
}


int main() {


    ifstream data;
//############################################################################
    int numberFile = 1;

    int numbersSize;
    switch(numberFile) {

        case 0:
            data.open("liczby_przyklad.txt");
            numbersSize = 50;
            break;
        case 1:
            data.open("liczby.txt");
            numbersSize = 300;
            break;

        default:
            cout << "Wrong file parameter!!!" << endl;
            numbersSize = 0;
            break;
    }

    if(data.good()) {
        cout << "File found!" << endl;
    }


    int *integers = new int[numbersSize];

    cout << "1)\n";
    ofstream out;
    out.open("wyniki4_1.txt");

    for(int i = 0; i < numbersSize; i++) {
        data >> integers[i];
        if(primeFromRange(integers[i], 100, 5000)) {
            cout << integers[i] << endl;
            out << integers[i] << endl;
        }
    }

    data.close();
    out.close();

    cout << "2)\n";
    out.open("wyniki4_2.txt");

//############################################################################
    int primeFile = 1;

    int primesSize;
    switch(primeFile) {

        case 0:
            data.open("pierwsze_przyklad.txt");
            primesSize = 50;
            break;
        case 1:
            data.open("pierwsze.txt");
            primesSize = 200;
            break;

        default:
            cout << "Wrong file parameter!!!" << endl;
            break;
    }


    int *primes = new int[primesSize];
    for(int i = 0; i < primesSize; i++) {
        data >> *(primes + i);
        if(primeFromBehind(primes[i])) {
            cout << primes[i] << endl;
            out << primes[i] << endl;
        }
    }
    data.close();
    out.close();

    cout << "3)\n";
    out.open("wyniki4_3.txt");

    int counter = 0;

    for(int i = 0; i < primesSize; i++) {

        if(weight(primes[i]) == 1) {
            counter++;
        }
    }

    cout << counter << endl;
    out << counter << endl;

    out.close();
}
