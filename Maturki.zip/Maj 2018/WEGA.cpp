#include<iostream>
#include<fstream>
#include<string>

using namespace std;

#define thisSize() 1000

void inputData(string *signals, ifstream &data) {

    for(int i = 0; i < thisSize(); i++) {
        data >> signals[i];
    }
}

int differentLetters(string signal) {

    int *alphabeth = new int[26]{0};

    for(int i = 0; i < signal.size(); i++) {
        alphabeth[signal[i] - 65]++;
    }

    int differentLetters = 0;
    for(int i = 0; i < 26; i++) {
        if(alphabeth[i] > 0) {
            differentLetters++;
        }
    }
    delete alphabeth;

    return differentLetters;
}

bool variesMaxBy10(string signal) {

    int *alphabeth = new int[26]{0};

    for(int i = 0; i < signal.size(); i++) {
        alphabeth[signal[i] - 65]++;
    }

    int lowestLetterIndex = 0;
    while(alphabeth[lowestLetterIndex] == 0) {
        lowestLetterIndex++;
    }
    int maxLetterIndex = 25;
    while(alphabeth[maxLetterIndex] == 0) {
        maxLetterIndex--;
    }

    return (maxLetterIndex - lowestLetterIndex <= 10);
}


int main() {

    ifstream data;

    ofstream out;
    out.open("wyniki4.txt");


    int file = 1;

    switch(file) {

        case 0:
            data.open("przyklad.txt");
            break;
        case 1:
            data.open("sygnaly.txt");
            break;
    }

    string *signals = new string[1000];

    inputData(signals, data);

    string firstMessage = "";
    int maxDifferentLetters = 0;
    string mostDiverseSignal;
    for(int i = 0; i < thisSize(); i++) {

        if((i + 1) % 40 == 0) {
            firstMessage += signals[i].at(9);
        }

        int currDifferentLetters = differentLetters(signals[i]);

        if(currDifferentLetters > maxDifferentLetters) {
            maxDifferentLetters = currDifferentLetters;
            mostDiverseSignal = signals[i];
        }

    }
    cout << "4.1) " << firstMessage << endl;
    out << "4.1) " << firstMessage << endl;

    cout << "4.2) " << mostDiverseSignal << "\t" << maxDifferentLetters << endl;
    out << "4.2) " << mostDiverseSignal << "\t" << maxDifferentLetters << endl;

    cout << "4.3)\n";
    out << "4.3)\n";
    for(int i = 0; i < thisSize(); i++) {

        if(variesMaxBy10(signals[i])) {
            cout << signals[i] << endl;
            out << signals[i] << endl;
        }
    }
}
