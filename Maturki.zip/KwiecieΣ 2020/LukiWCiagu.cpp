#include <iostream>
#include <fstream>
#include <cmath>
#include <map>

using namespace std;


int main() {


    ifstream data;
    data.open("dane4.txt");
    if(data.good()) {
        cout << "File found!" << endl;
    }


    int size = 1000;
    int *integers = new int[size];

    for(int i = 0; i < size; i++) {
        data >> integers[i];
    }

    ofstream out;
    out.open("zadanie4.txt");

    cout << "1)\n";
    out << "1)\n";
    int theBiggestGap = 0;
    int theLowestGap = 1000;
    int gap;
    for(int i = 1; i < size; i++) {
        gap = abs(integers[i] - integers[i - 1]);
        if(gap > theBiggestGap) {
            theBiggestGap = gap;
        }
        if(gap < theLowestGap) {
            theLowestGap = gap;
        }
    }

    cout << theBiggestGap << endl;
    cout << theLowestGap << endl;
    out << theBiggestGap << endl;
    out << theLowestGap << endl;


    cout << "2)\n";
    out << "2)\n";
    int previousGap = 0;
    int sequenceLength = 2;
    int maxLength = 1;
    int lastIndex;
    for(int i = 1; i < size; i++) {

        gap = abs(integers[i] - integers[i - 1]);
        if(gap != previousGap) {
            previousGap = gap;
            sequenceLength = 2;
            //dlaczego?

            // zaczynaj�c od pocz�tku, tworz� luk� pomi�dzy elementem na [i] i [i - 1],
            // wobec czego, w ci�gu mam ju� dwie liczby, wychodz�ce spod tych indeks�w
         }
        else {
            sequenceLength++;
        }

        if(sequenceLength > maxLength) {

            maxLength = sequenceLength;
            lastIndex = i;
        }
    }

    cout << maxLength << " " << integers[lastIndex - maxLength + 1] <<
                         " " << integers[lastIndex] << endl;
    out << maxLength << " " << integers[lastIndex - maxLength + 1] <<
                         " " << integers[lastIndex] << endl;


    cout << "3)\n";
    out << "3)\n";

    map<int, int>gapsMultiplicity;

    int maxMultiplicity = 0;
    for(int i = 1; i < size; i++) {
        gap = abs(integers[i] - integers[i - 1]);
        if(gapsMultiplicity.find(gap) == gapsMultiplicity.end()) {
            gapsMultiplicity.insert(pair<int, int>(gap, 1));
        }
        else {
            gapsMultiplicity.at(gap)++;

            if(gapsMultiplicity.at(gap) > maxMultiplicity) {
                maxMultiplicity = gapsMultiplicity[gap];
            }
        }
    }
    cout << maxMultiplicity << endl;
    out << maxMultiplicity << endl;
    for(auto pair : gapsMultiplicity) {
        if(pair.second == maxMultiplicity) {
            cout << pair.first << " ";
            out << pair.first << " ";
        }
    }
    cout << endl;
    out << endl;

}
