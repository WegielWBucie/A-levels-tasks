#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>

using namespace std;

bool prime(int integer) {

    if(integer < 2) {
        return false;
    }
    if(integer == 2) {
        return true;
    }
    else if(integer % 2 == 0) {
        return false;
    }

    for(int i=3; i<=sqrt(integer); i+=2) {
        if(integer % i == 0) {
            return false;
        }
    }

    return true;
}


int main()
{
    ifstream data;
    data.open("dane.txt");

    vector<int>happyNumbers;

    for(int i=0; i<10000; i+= 2) {
        happyNumbers.push_back(i + 1);
    }
    for(int i=1; i<happyNumbers.size(); i++) {

        int currentHappy  = happyNumbers.at(i);

        int counter = 0;
        for(int j=0; j<happyNumbers.size(); j++) {
            if((j + 1 + counter) % currentHappy == 0) {
                happyNumbers.erase(happyNumbers.begin() + j);
                counter++;
            }
        }
    }

    vector<int>integers;

    int currentNumber;
    while(data >> currentNumber) {
        integers.push_back(currentNumber);
    }

    int happyCounter = 0, happyFirstCounter = 0;

    int longestSequence = 0, sequence = 0, lastIndex;

    bool foundHappy;

    for(int i=0; i<integers.size(); i++) {

        foundHappy = false;

        for(int j=0; j<happyNumbers.size(); j++) {

            if(integers[i] == happyNumbers[j]) {

                happyCounter++;
                sequence++;
                foundHappy = true;

                if(sequence > longestSequence) {
                    longestSequence = sequence;
                    lastIndex = i;
                }

                if(prime(integers[i])) {

                    happyFirstCounter++;

                }
                break;
            }
        }
        if(!foundHappy) {
            sequence = 0;
        }

    }

    cout << "1) " << happyCounter << endl;
    cout << "2) " << longestSequence << " " << integers[lastIndex - longestSequence + 1] << endl;
    cout << "3) " << happyFirstCounter << endl;



}
