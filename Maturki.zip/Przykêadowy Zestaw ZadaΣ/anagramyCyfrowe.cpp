#include<iostream>
#include<fstream>

using namespace std;


bool digitalAnagrams(int firstNumber, int secondNumber) {

    int firstSum = 0, secondSum = 0;
    int copyFirstNumber = firstNumber, copySecondNumber = secondNumber;

    while(copyFirstNumber > 0 && copySecondNumber > 0) {
        firstSum += copyFirstNumber % 10;
        secondSum += copySecondNumber % 10;

        copyFirstNumber /= 10;
        copySecondNumber /= 10;
    }

    if(firstSum != secondSum || copyFirstNumber + copySecondNumber > 0) {
        return false;
    }

    int numbers[2][10] = {0};
    while(firstNumber > 0) {
        numbers[0][firstNumber % 10]++;
        numbers[1][secondNumber % 10]++;

        firstNumber /= 10;
        secondNumber /= 10;
    }

    for(int i = 0; i < 10; i++) {
        if(numbers[0][i] != numbers[1][i]) {
            return false;
        }
    }
    return true;
}

#define size() 1000

int main() {


    ifstream data;
    data.open("dane_anagramy.txt");

    ofstream out;
    out.open("wyniki_anagramy.txt");

    int firstNumber, secondNumber;

    int **integers = new int*[1000];

    int anagramPairsCounter = 0;
    int i = 0;
    while(data >> firstNumber >> secondNumber) {

        integers[i] = new int[2];
        integers[i][0] = firstNumber;
        integers[i][1] = secondNumber;
        i++;

        cout << firstNumber << " " << secondNumber << endl;

        if(digitalAnagrams(firstNumber, secondNumber)) {
            anagramPairsCounter++;
        }
    }

    cout << "a) " << anagramPairsCounter << endl;


    int maxAnagrams = 0;
    int anagramsCounter;
    for(int i = 0; i < size() - 1; i++) {

        for(int j = 0; j < 2; j++) {

            anagramsCounter = 0;

            firstNumber = integers[i][j];

            secondNumber = integers[i][(j + i) % 2];

            if(digitalAnagrams(firstNumber, secondNumber)) {
                anagramsCounter++;
            }
            for(int k = i; k < size(); k++) {
                for(int l = 0; l < 2; l++) {

                    secondNumber = integers[k][l];
                    if(digitalAnagrams(firstNumber, secondNumber)) {
                        anagramsCounter++;
                    }
                }
            }
            if(anagramsCounter > maxAnagrams) {
                maxAnagrams = anagramsCounter;
            }
        }

    }

    cout << "b) " << maxAnagrams << endl;
}
