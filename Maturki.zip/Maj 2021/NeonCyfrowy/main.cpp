#include <iostream>
#include <fstream>

using namespace std;

int main() {

    ifstream data;
    data.open("C:/Users/pondr/Desktop/MATURY/Maj 2021/instrukcje.txt");
    int size = 2000;
    auto **instructions = new string*[size];

    int length = 0;

    for(int i=0; i<size; i++) {
        instructions[i] = new string[2];

        data >> instructions[i][0] >> instructions[i][1];
        if(instructions[i][0] == "DOPISZ") {
            length++;
        }
        else if(instructions[i][0] == "USUN") {
            length--;
        }
    }

    cout << "4.1) " << length << endl;

    int maxLength = 0;
    string instruction;
    for(int i=1; i<size; i++) {
        length = 1;
        while(instructions[i][0] == instructions[i - 1][0]) {
            length++;
            i++;
        }
        if(length > maxLength) {
            maxLength = length;
            instruction = instructions[i - 1][0];
        }
    }

    cout << "4.2) " << instruction << "\t" << maxLength << endl;

    int *lettersCounter = new int[26]{0};


    for(int i=0; i<size; i++) {
        if(instructions[i][0] == "DOPISZ") {
            lettersCounter[instructions[i][1][0] - 65]++;
        }
    }

    int mostFrequency = 0;
    char letter;
    for(int i=0; i<26; i++) {
        if(lettersCounter[i] > mostFrequency) {
            mostFrequency = lettersCounter[i];
            letter = char(i + 65);
        }
    }

    cout << "4.3) " << letter << "\t" << mostFrequency << endl;

    string finalResult = "";
    for(int i=0; i<size; i++) {

        if(instructions[i][0] == "DOPISZ") {
            finalResult.append(instructions[i][1]);
        }
        else if(instructions[i][0] == "USUN") {
            finalResult.erase(finalResult.size() - 1);
        }
        else if(instructions[i][0] == "ZMIEN") {
            finalResult.at(finalResult.size() - 1) = instructions[i][1][0];
        }
        else if(instructions[i][0] == "PRZESUN") {
            for(char & j : finalResult) {
                if(j == instructions[i][1][0]) {
                    j = char(65 + (j - 65 + 1) % 26);
                    break;
                }
            }
        }
    }

    cout << "4.4) " << finalResult << endl;


}
