#include<iostream>
#include<fstream>
#include<cmath>

using namespace std;


int fewerRowsToDelete(int **pixels, int length, int width) {
    //length = 200
    //width = 320
    int rows = 0;
    for(int i = 0; i < length; i++) {
        for(int j = 0; j < width; j++) {
            if(pixels[i][j] != pixels[i][width - j - 1]) {
                rows++;
                break;
            }
        }
    }
    return rows;
}

int longestVerticalLine(int **pixels, int length, int width) {

    int longestLine = 0, lineLength;
    for(int i = 0; i < width; i++) {
        lineLength = 1;
        for(int j = 1; j < length; j++) {
            if(pixels[j][i] == pixels[j - 1][i]) {
                lineLength++;
            }
            else {
                lineLength = 1;
            }
            if(lineLength > longestLine) {
                longestLine = lineLength;
            }
        }
    }
    return longestLine;
}


int main() {

    ifstream data;

    int file = 1;

    switch(file) {

        case 0:
            data.open("przyklad.txt");
            break;
        case 1:
            data.open("dane.txt");
            break;
    }
    int length = 200, width = 320;

    int **pixels = new int *[length];

    int theBrightest = 0, theDarkest = 255;
    for(int i = 0; i < length; i++) {
        pixels[i] = new int[width];
        for(int j = 0; j < width; j++) {

            data >> pixels[i][j];
            if(pixels[i][j] > theBrightest) {
                theBrightest = pixels[i][j];
            }
            if(pixels[i][j] < theDarkest) {
                theDarkest = pixels[i][j];
            }
        }
    }

    cout << "6.1)" << endl;
    cout << "Brightest: " << theBrightest << endl << "Darkest: " << theDarkest << endl;

    cout << "6.2) " << fewerRowsToDelete(pixels, 200, 320) << endl;

    int contrastNeighbors = 0;
    for(int i = 0; i < length; i++) {

        for(int j = 0; j < width; j++) {

            bool contrast = false;

            if(i > 0) {
                if(abs(pixels[i][j] - pixels[i - 1][j]) > 128) {
                    contrast = true;
                }
            }
            if(j > 0) {
                if(abs(pixels[i][j] - pixels[i][j - 1]) > 128) {
                    contrast = true;
                }
            }
            if(i < 199) {
                if(abs(pixels[i][j] - pixels[i + 1][j]) > 128) {
                    contrast = true;
                }
            }
            if(j < 319) {
                if(abs(pixels[i][j] - pixels[i][j + 1]) > 128) {
                    contrast = true;
                }
            }
            if(contrast) {
                contrastNeighbors++;
            }
        }
    }
    cout << "6.3) " << contrastNeighbors << endl;
    cout << "6.4) " << longestVerticalLine(pixels, 200, 320) << endl;


}
