#include <iostream>
#include <fstream>
#include <vector>


using namespace std;


bool evenAndOdd5Times(int *firstSequence, int *secondSequence) {
            //even  //odd
    //first
    //second
    int counters[2][2] = {0};


    for(int i = 0; i < 10; i++) {
        counters[0][firstSequence[i] % 2]++;
        counters[1][secondSequence[i] % 2]++;
    }

    return(counters[0][0] == 5 && counters[0][1] == 5
           && counters[1][0] == 5 && counters[1][1] == 5);

}


bool madeFromTheSameLetters(int *firstSequence, int *secondSequence) {

    vector<int>firstSeqNumbers;
    firstSeqNumbers.push_back(firstSequence[0]);
    vector<int>secondSeqNumbers;
    secondSeqNumbers.push_back(secondSequence[0]);

    for(int i = 1; i < 10; i++) {
        if(firstSequence[i] != firstSequence[i - 1]) {
            firstSeqNumbers.push_back(firstSequence[i]);
        }
        if(secondSequence[i] != secondSequence[i - 1]) {
            secondSeqNumbers.push_back(secondSequence[i]);
        }

    }

    if(firstSeqNumbers.size() != secondSeqNumbers.size()) {
        return false;
    }

    for(int i = 0; i < firstSeqNumbers.size(); i++) {
        if(firstSeqNumbers[i] != secondSeqNumbers[i]) {
            return false;
        }
    }


    return true;
}


int *mergeSequences(int *firstSequence, int *secondSequence) {

    int firstIterator = 0;
    int secondIterator = 0;

    int *mergedSequence = new int[20];
    int mergedIterator = 0;


    while(firstIterator < 10 && secondIterator < 10) {

        if(firstSequence[firstIterator] <= secondSequence[secondIterator]) {

            mergedSequence[mergedIterator] = firstSequence[firstIterator];
            mergedIterator++;
            firstIterator++;
        }
        if(firstSequence[firstIterator] >= secondSequence[secondIterator]) {

            mergedSequence[mergedIterator] = secondSequence[secondIterator];
            mergedIterator++;
            secondIterator++;
        }
    }

    while(firstIterator < 10) {
        mergedSequence[mergedIterator] = firstSequence[firstIterator];
        mergedIterator++;
        firstIterator++;
    }

    while(secondIterator < 10) {
        mergedSequence[mergedIterator] = secondSequence[secondIterator];
        mergedIterator++;
        secondIterator++;
    }

    return mergedSequence;

}



int main() {


    ifstream firstFile;
    ifstream secondFile;
    int file = 1;

    ofstream file1("wynik4_1.txt");
    ofstream file2("wynik4_2.txt");
    ofstream file3("wynik4_3.txt");
    ofstream file4("wynik4_4.txt");

    int size;
    switch(file) {

        case 0:
            firstFile.open("przyklad1.txt");
            secondFile.open("przyklad2.txt");
            size = 5;
            break;
        case 1:
            firstFile.open("dane1.txt");
            secondFile.open("dane2.txt");
            size = 1000;
            break;

        default:
            cout << "WRONG FILE PARAMETER!" << endl;
    }


    int sameLastNumberCounter = 0;
    int evenAndOdd5TimesCounter = 0;

    int madeFromTheSameLettersCounter = 0;
    vector<int>rows;

    for(int i = 0; i < size; i++) {

        int *firstSequence = new int[10], *secondSequence = new int[10];

        for(int j = 0; j < 10; j++) {

            firstFile >> firstSequence[j];
            secondFile >> secondSequence[j];
        }

        if(firstSequence[9] == secondSequence[9]) {
            sameLastNumberCounter++;
        }

        if(evenAndOdd5Times(firstSequence, secondSequence)) {
            evenAndOdd5TimesCounter++;
        }

        if(madeFromTheSameLetters(firstSequence, secondSequence)) {
            madeFromTheSameLettersCounter++;
            rows.push_back(i + 1);
        }


        int *mergedSequence = mergeSequences(firstSequence, secondSequence);

        for(int j = 0; j < 20; j++) {
            cout << mergedSequence[j] << " ";
            file4 << mergedSequence[j] << " ";
        }
        cout << endl;
        file4 << endl;

    }

    cout << sameLastNumberCounter << endl;
    file1 << sameLastNumberCounter << endl;

    cout << evenAndOdd5TimesCounter << endl;
    file2 << evenAndOdd5TimesCounter << endl;

    cout << madeFromTheSameLettersCounter << endl;
    file3 << madeFromTheSameLettersCounter << endl;
    for(int i = 0; i < rows.size(); i++) {
        cout << rows[i] << " ";
        file3 << rows[i] << " ";
    }
    cout << endl;

    rows.clear();

}
