#include <iostream>
#include <fstream>
#include <vector>

using namespace std;


struct Identificator {

    string series;
    string number;

};

bool palindrome(Identificator ID) {

    bool seriesPalindrome = true;
    bool numberPalindrome = true;
    for(int i=0; i<ID.number.size() / 2; i++) {
        if(ID.series.at(i / 2) != ID.series.at(ID.series.size() - 1 - i / 2)) {
            seriesPalindrome = false;
        }
        if(ID.number.at(i) != ID.number.at(ID.number.size() - 1 - i)) {
            numberPalindrome = false;
        }
    }

    return (seriesPalindrome || numberPalindrome);
}


int main()
{
    ifstream data;
    ofstream out;


    int file = 1;
    int size;
    switch(file) {

        case 0:
            data.open("identyfikator_przyklad.txt");
            size = 20;
            break;
        case 1:
            data.open("identyfikator.txt");
            size = 200;
            break;
    }

    if(data.good()) {
        cout << "File found!\n";
    }

    auto *identificators = new Identificator[size];
    string ID;

    vector<Identificator>IDsWithTheBiggestSum;
    int sum, biggestSum = 0;

    for(int i=0; i<size; i++) {
        data >> ID;
        identificators[i].series = ID.substr(0, 3);
        identificators[i].number = ID.substr(3, 6);

        sum = 0;

        for(int j=0; j<identificators[i].number.size(); j++) {
            sum += (identificators[i].number[j] - 48);
        }

        if(sum > biggestSum) {
            biggestSum = sum;
            IDsWithTheBiggestSum.clear();
        }
        if(sum == biggestSum) {
            IDsWithTheBiggestSum.push_back(identificators[i]);
        }
    }

    cout << "1)\n";
    out.open("wyniki4_1.txt");
    for(int i=0; i<IDsWithTheBiggestSum.size(); i++) {
        cout << IDsWithTheBiggestSum[i].series << IDsWithTheBiggestSum[i].number << endl;
        out << IDsWithTheBiggestSum[i].series << IDsWithTheBiggestSum[i].number << endl;
    }
    out.close();

    cout << "2)\n";
    out.open("wyniki4_2.txt");

    for(int i=0; i<size; i++) {
        if(palindrome(identificators[i])) {
            cout << identificators[i].series << identificators[i].number << endl;
            out << identificators[i].series << identificators[i].number << endl;
        }
    }
    out.close();

    cout << "3)\n";
    out.open("wyniki4_3.txt");
    int *weights = new int[8] {7, 3, 1, 7, 3, 1, 7, 3};

    for(int i=0; i<size; i++) {

        sum = 0;
        for(int j=0; j<identificators[i].series.size(); j++) {
            sum += weights[j] * (identificators[i].series[j] - 55);
        }

        for(int j=1; j<identificators[i].number.size(); j++) {
            sum += weights[j + 2] * (identificators[i].number[j] - 48);

        }
        if(sum % 10 != identificators[i].number[0] - 48) {
            cout << identificators[i].series << identificators[i].number << endl;
            out << identificators[i].series << identificators[i].number << endl;
        }
    }
    out.close();

    delete [] identificators;


}
