#include<iostream>
#include<fstream>
#include<map>

using namespace std;


int evenPositionsSum(string number) {
    int sum = 0;
    for(int i = number.size() - 1; i>=0; i -= 2) {
        sum += number.at(i) - 48;
    }
    return sum;
}

int oddPositionsSum(string number) {

    int sum = 0;
    for(int i = number.size() - 2; i>=0; i -= 2) {
        sum += number.at(i) - 48;
    }
    return sum;
}

int controlDigit(string number) {

    return (10 - ((3 * evenPositionsSum(number) +
                  oddPositionsSum(number))% 10)) % 10;
}


int main() {

    ifstream data;
    data.open("kody.txt");
    ifstream standard;
    standard.open("cyfra_kodkreskowy.txt");

    ofstream out;
    out.open("kody1.txt");

    int size = 500;
    string *codes = new string[size];

    for(int i = 0; i < size; i++) {
        data >> codes[i];
        out << evenPositionsSum(codes[i]) << " " <<
                oddPositionsSum(codes[i]) << endl;
    }
    data.close();
    out.close();

    string firstLine;
    getline(standard, firstLine);
    map<string, string>standardCodes;
    string ID, code;
    for(int i = 0; i < 10; i++) {
        standard >> ID >> code;
        standardCodes.insert(pair<string,string>(ID, code));
    }
    standard.close();

    out.open("kody2.txt");

    for(int i = 0; i < size; i++) {
        out << controlDigit(codes[i]) << " " << standardCodes.at(to_string(controlDigit(codes[i]))) << endl;
    }
    out.close();

    out.open("kody3.txt");
    standardCodes.insert(pair<string, string>("START", "11011010"));
    standardCodes.insert(pair<string, string>("STOP", "11010110"));
    string letter;
    for(int i = 0; i < size; i++) {

        out << standardCodes.at("START");
        for(int j = 0; j < codes[i].size(); j++) {
            letter = codes[i].substr(j, 1);
            out << standardCodes.at(letter);
        }
        out << standardCodes.at(to_string(controlDigit(codes[i])));
        out << standardCodes.at("STOP") << endl;
    }
    out.close();
}
