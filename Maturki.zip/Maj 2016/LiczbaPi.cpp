#include<iostream>
#include<fstream>
#include<cmath>

using namespace std;

struct Point {

    int x;
    int y;

};

struct Circle {

    int x;
    int y;
    int r;
};

int square(int a) {
    return a * a;
}

bool edge(Point point, Circle circle) {

    return (square(circle.x - point.x) + square(circle.y - point.y)
       == square(circle.r));
}

bool inside(Point point, Circle circle) {

    return (square(circle.x - point.x) + square(circle.y - point.y)
       < square(circle.r));
}

struct Square {
    int a;
    int Area;
    int points;
};

int exponentiation(int number, int exponent) {

    if(exponent == 0) {
        return 1;
    }
    int result = number;
    for(int i = 1; i < exponent; i++) {
        result *= number;
    }
    return result;
}

float Round(float number, float decimals) {

    return round(number * exponentiation(10, decimals)) / exponentiation(10, decimals);
}

float approximatePi(Point *points, Circle circle, Square square, int n) {

    float belonging = 0;
    for(int i = 0; i < n; i++) {
        if(inside(points[i], circle) || edge(points[i], circle)) {
            belonging++;
        }
    }
    return Round(float(square.Area) * belonging /
                 (float(n) * (float)circle.r * (float)circle.r), 4);
}

float absoluteError(Point *points, Circle circle, Square square, int n) {

    return abs(M_PI - approximatePi(points, circle,square, n));

}

int main() {

    ifstream data;

    data.open("punkty.txt");

    ofstream out;

    int size = 10000;
    Point *points = new Point[size];

    Circle circle;
    circle.x= 200;
    circle.y = 200;
    circle.r = 200;

    Square square;
    square.a = 400;
    square.Area = square.a * square.a;
    square.points = 10000;

    int edgePoints = 0, insidePoints = 0;

    cout << "1)\n";
    for(int i = 0; i < size; i++) {
        data >> points[i].x >> points[i].y;
        if(edge(points[i], circle)) {
            edgePoints++;
            cout << "("<< points[i].x << ", " << points[i].y << ")" << endl;
            out << "("<< points[i].x << ", " << points[i].y << ")" << endl;
        }
        else if(inside(points[i], circle)) {
            insidePoints++;
        }
    }

    out.open("wyniki4.txt");
    cout << insidePoints << endl;
    out << insidePoints << endl;

    cout << "2)\n";
    out << "2)\n";
    cout << approximatePi(points, circle, square, 1000) << endl;
    cout << approximatePi(points, circle, square, 5000) << endl;
    cout << approximatePi(points, circle, square, 10000) << endl;
    out << approximatePi(points, circle, square, 1000) << endl;
    out << approximatePi(points, circle, square, 5000) << endl;
    out << approximatePi(points, circle, square, 10000) << endl;

    cout << "3)\n";
    out << "3)\n";
    ofstream graphOut("graphOutput.txt");
    graphOut << "n\t" << "Absolute error" << endl;
    for(int i = 1; i <= 1700; i++) {

        float error = absoluteError(points, circle, square, i);
        graphOut << i << "\t" << error << endl;

        if(i == 1000 || i == 1700) {
            cout << Round(error,4) << endl;
            out << Round(error,4) << endl;
        }
    }
    graphOut.close();
    out.close();
}
