#include<iostream>
#include<fstream>
#include<vector>

using namespace std;


string encryption(string word, int key) {

    string result;
    key = key % 26;
    for(char letter : word) {
        result += 65 + ((letter - 65 + key) % 26);
    }
    return result;
}

string decryption(string word, int key) {

    string result;
    key = key % 26;
    for(char letter : word) {
        if(letter - key >= 65) {
            result += letter - key;
        }
        else {
            result += 91 + (letter - 65 - key);
        }
    }
    return result;
}


int main() {


    ifstream data;
    ofstream out;

    data.open("dane_6_1.txt");
    out.open("wyniki_6_1.txt");

    int size = 100;
    string *words = new string[size];

    int key = 107;
    for(int i = 0; i < size; i++) {
        data >> words[i];

        out << encryption(words[i], key) << endl;
    }
    data.close();
    out.close();

    delete [] words;
    data.open("dane_6_2.txt");
    out.open("wyniki_6_2.txt");

    size = 3000;
    pair<string, int> *codedWords = new pair<string, int>[size];
    //vector<pair<string, int>>codedWords;

    for(int i = 0; i < size; i++) {
        data >> codedWords[i].first >> codedWords[i].second;
        out << decryption(codedWords[i].first, codedWords[i].second) << endl;
    }
    data.close();
    out.close();

    data.open("dane_6_3.txt");
    out.open("wyniki_6_3.txt");
    delete [] codedWords;

    struct Code {

        string word;
        int key;

    };

    pair<Code, string> *wordPairs = new pair<Code, string>[size];
    for(int i = 0; i < size; i++) {
        data >> wordPairs[i].first.word >> wordPairs[i].second;
        wordPairs[i].first.key =
            wordPairs[i].second[0] - wordPairs[i].first.word[0];
        if(wordPairs[i].first.key < 0) {
            wordPairs[i].first.key += 26;
        }
        if(encryption(wordPairs[i].first.word, wordPairs[i].first.key) != wordPairs[i].second) {

            out << wordPairs[i].first.word << endl;
        }
    }
    data.close();
    out.close();
}
