#include <iostream>
#include <fstream>
#include <string>

using namespace std;

bool palindrome(string subtitle) {

    for(int i = 0; i < subtitle.size() / 2; i++) {
        if(subtitle[i] != subtitle[subtitle.size() - 1 - i]) {
            return false;
        }
    }
    return true;
}

int main()
{
    ifstream data;
    ofstream out;
    out.open("wyniki_4.txt");
    int file = 1;
    switch(file) {

        case 0:
            data.open("przyklad.txt");
            break;
        case 1:
            data.open("napisy.txt");
            break;
    }
    int size = 1000;

    int numbersCounter = 0;
    string secretPassword = "";
    string palindromePassword = "";
    string lastPassword = "";

    string *subtitles = new string[1000];
    for(int i=0; i<size; i++) {

        data >> *(subtitles + i);
        for(int j=0; j<subtitles[i].size(); j++) {
            if(subtitles[i][j] >= 48 && subtitles[i][j] <= 57) {
                numbersCounter++;
            }
        }
        if(i%20 == 19) {
            secretPassword += subtitles[i][i / 20];
        }

        string trialPalindrome = subtitles[i][49] + subtitles[i];
        if(palindrome(trialPalindrome)) {
            palindromePassword += trialPalindrome[25];
        }
        trialPalindrome = subtitles[i] + subtitles[i][0];
        if(palindrome(trialPalindrome)) {
            palindromePassword += trialPalindrome[25];
        }

        int number = 0;

        for(int j=0; j<subtitles[i].size(); j++) {

            if(number >= 10) {
                number = 0;
            }

            if(subtitles[i][j] >= 48 && subtitles[i][j] <= 57) {
                number = 10 * number + (subtitles[i][j] - 48);
            }
            if(number >= 65 && number <= 90) {
                lastPassword += char(number);
            }

            if(lastPassword[lastPassword.size() - 1] == 'X' &&
                    lastPassword[lastPassword.size() - 2] == 'X' &&
                    lastPassword[lastPassword.size() - 3] == 'X') {

                break;
            }
        }
    }
    data.close();

    cout << numbersCounter << endl;
    cout << secretPassword << endl;
    cout << palindromePassword << endl;
    cout << lastPassword << endl;
    out << numbersCounter << endl;
    out << secretPassword << endl;
    out << palindromePassword << endl;
    out << lastPassword << endl;

    out.close();
}
