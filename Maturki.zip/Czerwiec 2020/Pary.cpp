#include<iostream>
#include<fstream>
#include<cmath>

using namespace std;


bool prime(int number) {

    if(number < 2) {
        return false;
    }
    if(number == 2) {
        return true;
    }
    if(number % 2 == 0) {
        return false;
    }

    for(int i = 3; i <= sqrt(number); i += 2) {
        if(number % i == 0) {
            return false;
        }
    }
    return true;
}


int *primeComponents(int number) {


    int *components = new int[2];


    for(int i = 3; i <= number / 2; i += 2) {
        if(prime(i) && prime(number - i)) {
            *components = i;
            *(components + 1) = number - i;
            break;
        }
    }

    return components;
}

pair<int, string>longestSequence(string subtitle) {

    int sequenceLength = 1;
    int maxLength = 1;
    string sequence = "";
    sequence += subtitle[0];
    for(int i = 1; i < subtitle.size(); i++) {

        if(subtitle[i] == subtitle[i - 1]) {
            sequenceLength++;
        }
        else {
            sequenceLength = 1;
        }

        if(sequenceLength > maxLength) {
            maxLength = sequenceLength;
            sequence = subtitle.substr(i - sequenceLength + 1, sequenceLength);
        }
    }

    return pair<int, string>(maxLength, sequence);

}


bool lowerPair(pair<int, string>firstPair, pair<int, string>secondPair) {

    if(firstPair.first < secondPair.first) {
        return true;
    }
    else if(firstPair.first == secondPair.first) {
        int i = 0;
        int size = firstPair.second.size() > secondPair.second.size() ?
            firstPair.second.size() : secondPair.second.size();

        while(firstPair.second.at(i) == secondPair.second.at(i) && i < size) {
            i++;
        }

        if(firstPair.second.at(i) < secondPair.second.at(i)) {
            return true;
        }
        else if(firstPair.second.at(i) == secondPair.second.at(i)) {

            return firstPair.second.size() < secondPair.second.size();
        }
        else {
            return false;
        }
    }
    else {
        return false;
    }

}


int main() {

    ifstream data;

    int file = 1;
    int size = 100;

    switch(file) {

        case 0:
            data.open("przyklad.txt");
            break;
        case 1:
            data.open("pary.txt");
            break;

    }

    ofstream out;
    out.open("wyniki4.txt");

    auto *pairs = new pair<int, string>[size];

    cout << "1)\n";
    out << "1)\n";
    for(int i = 0; i < size; i++) {

        data >> pairs[i].first >> pairs[i].second;

        if(pairs[i].first % 2 == 0 && pairs[i].first > 4) {
            int *components = primeComponents(pairs[i].first);
            cout << pairs[i].first << " " << components[0] << " " << components[1] << endl;
            out << pairs[i].first << " " << components[0] << " " << components[1] << endl;

        }

    }

    cout << "2)\n";
    out << "2)\n";
    for(int i = 0; i < size; i++) {
        pair<int, string>currentPair = longestSequence(pairs[i].second);
        //cout << currentPair.second << " " << currentPair.first << endl;
        cout << pairs[i].second << " " <<currentPair.second << " " << currentPair.first << endl;
    }


    cout << "3)\n";
    out << "3)\n";
    pair<int, string>theTiniestPair(1000, "zzzzzzzzz");

    for(int i = 0; i < size; i++) {

        if(pairs[i].first == pairs[i].second.size()) {

            if(lowerPair(pairs[i],theTiniestPair)) {
                theTiniestPair = pairs[i];
            }

        }

    }
    cout << theTiniestPair.first << " " << theTiniestPair.second << endl;
    out << theTiniestPair.first << " " << theTiniestPair.second << endl;

}
