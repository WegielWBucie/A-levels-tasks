#include<iostream>
#include<fstream>
#include<cmath>
#include<map>

using namespace std;

struct Point {

    int x;
    int y;

};

bool prime(int number) {

    if(number < 2) {
        return false;
    }
    if(number == 2) {
        return true;
    }
    if(number % 2 == 0) {
        return false;
    }

    for(int i = 3; i <= sqrt(number); i += 2) {
        if(number % i == 0) {
            return false;
        }
    }
    return true;
}

int square(int a) {

    return a*a;
}

int distance(Point A, Point B) {

    return sqrt(square(A.x - B.x) + square(A.y - B.y));
}

bool insideSquare(Point point) {

    return (abs(point.x) < 5000 && abs(point.y) < 5000);
}

bool atTheEdge(Point point) {

    return (abs(point.x) == 5000 || abs(point.y) == 5000);
}

bool digitallike(Point point) {


    map<int, int>digits;

    while(point.x > 0) {

        digits.insert(pair<int, int>(point.x % 10, 0));
        point.x /= 10;
    }

    while(point.y > 0) {

        if(digits.find(point.y % 10) == digits.end()) {
            return false;
        }
        else {
            digits.at(point.y % 10)++;
        }
        point.y /= 10;
    }

    for(auto digit : digits) {
        if(digit.second == 0) {
            return false;
        }
    }
    return true;
}

#define size() 1000

int main() {

    ifstream data;
    data.open("punkty.txt");

    ofstream out;
    out.open("wyniki4.txt");

    Point *points = new Point[size()];

    int primePoints = 0, digitallikePoints = 0;
    for(int i = 0; i < size(); i++) {

        data >> points[i].x >> points[i].y;

        if(prime(points[i].x) && prime(points[i].y)) {
            primePoints++;
        }

        if(digitallike(points[i])) {
            digitallikePoints++;
        }
    }
    data.close();

    cout << "4.1) " << primePoints << endl;
    out << "4.1) " << primePoints << endl;

    cout << "4.2) " << digitallikePoints << endl;
    out << "4.2) " << digitallikePoints << endl;

    int maxDistance = 0, currentDistance;

    Point A, B;

    for(int i = 0; i < size() - 1; i++) {

        for(int j = i + 1; j < size(); j++) {
            currentDistance = distance(points[i], points[j]);
            if(currentDistance > maxDistance) {
                maxDistance = currentDistance;
                A = points[i];
                B = points[j];
            }
        }
    }

    cout << "4.3) " << maxDistance << endl;
    cout << "A = (" << A.x << ", " << A.y << ")" << endl;
    cout << "B = (" << B.x << ", " << B.y << ")" << endl;

    out << "4.3) " << maxDistance << endl;
    out << "A = (" << A.x << ", " << A.y << ")" << endl;
    out << "B = (" << B.x << ", " << B.y << ")" << endl;

    int inside = 0, edge = 0, outside = 0;

    for(int i = 0; i < size(); i++) {

        if(insideSquare(points[i])) {
            inside++;
        }
        else if(atTheEdge(points[i])) {
            edge++;
        }
        else {
            outside++;
        }
    }

    cout << "4.4)\na " << inside << "\nb " << edge << "\nc " << outside << endl;
    out << "4.4)\na " << inside << "\nb " << edge << "\nc " << outside << endl;

    out.close();
    delete [] points;
}
