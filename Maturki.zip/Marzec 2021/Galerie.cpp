#include<iostream>
#include<fstream>
#include<map>
#include<vector>

using namespace std;


void doSort(int *areas, int localsAmount) {

    for(int i=0; i<localsAmount - 1; i++) {
        for(int j=0; j<localsAmount - 1 - i ; j++) {
            if(areas[j] > areas[j + 1]) {
                swap(areas[j], areas[j + 1]);
            }
        }
    }
}

int main()
{
    int size;
    ifstream data;

    int file = 1;
    if(file == 0) {
        data.open("galerie_przyklad.txt");
        size = 10;
    }
    else if(file == 1) {
        data.open("galerie.txt");
        size = 50;
    }

    map<string, int>citiesCounter;
    string ID, cityName;

    string *countryID = new string[size];
    string *cities = new string[size];
    int **measurements = new int*[size];

    for(int i=0; i<size; i++) {

        measurements[i] = new int[140];
        data >> countryID[i] >> cities[i];
        for(int j=0; j<140; j++) {
            data >> measurements[i][j];
        }
        if(citiesCounter.find(countryID[i]) == citiesCounter.end()) {
            citiesCounter.insert(pair<string,int>(countryID[i], 1));
        } else {
            citiesCounter.at(countryID[i])++;
        }
    }
    data.close();


    cout << "4.1)\n";
    for(auto &city : citiesCounter) {
        cout << city.first << " " << city.second << endl;
    }

    cout << "4.2a)\n";
    int *totalArea = new int[size]{0}, *localsAmount = new int[size]{0};
    for(int i=0; i<size; i++) {
        for(int j=0; j<140; j+=2) {
            if(measurements[i][j] != 0) {
                localsAmount[i]++;
                totalArea[i] += measurements[i][j] * measurements[i][j+1];

            } else {
                break;
            }
        }
        cout << cities[i] << " " << totalArea[i] << " " << localsAmount[i] << endl;
    }


    int maxArea = 0, minArea = 10000, maxIndex, minIndex;
    for(int i=0; i<size; i++) {
        if(totalArea[i] > maxArea) {
            maxArea = totalArea[i];
            maxIndex = i;
        }
        if(totalArea[i] < minArea) {
            minArea = totalArea[i];
            minIndex = i;
        }
    }
    cout << "4.2b)\n";
    cout << cities[maxIndex] << " " << totalArea[maxIndex] << endl;
    cout << cities[minIndex] << " " << totalArea[minIndex] << endl;


    cout << "4.3)\n";

    int sameKindLocals;
    int maxDiffLocals = 0, minDiffLocals = 1000;
    int **areas = new int*[size];

    for(int i=0; i<size; i++) {

        areas[i] = new int[localsAmount[i]];
        for(int j=0; j<localsAmount[i] * 2; j+=2) {
            areas[i][j / 2] = measurements[i][j] * measurements[i][j+1];
        }
        doSort(areas[i], localsAmount[i]);

        sameKindLocals = 0; //we do count only duplicates, cause first
                            //one ale kind of different types
        for(int j=1; j<localsAmount[i]; j++) {
            if(areas[i][j] == areas[i][j - 1]) {
                sameKindLocals++;
            }
        }
        if(localsAmount[i] - sameKindLocals > maxDiffLocals) {
            maxDiffLocals = localsAmount[i] - sameKindLocals;
            maxIndex = i;
        }
        if(localsAmount[i] - sameKindLocals < minDiffLocals) {
            minDiffLocals = localsAmount[i] - sameKindLocals;
            minIndex = i;

        }
    }
    cout << cities[maxIndex] << " " << maxDiffLocals << endl;
    cout << cities[minIndex] << " " << minDiffLocals << endl;

    /*
    PONI�SZY KOD WYPISALBY DLA KAZDEGO MIASTA, ILE JEST TEGO SAMEGO RODZAJU
    ! GALERII !, NIE LOKALI, TAK JAK W ZADANIU, ale w sumie nwm czy dzia�a boo
    nie mia�em adekwatnych danych �eby to sprawdzi�, imo powinien xD

    int *differentLocals = new int[size];

    map<string, vector<int>>citiesLocals;
    for(int i=0; i<size; i++) {
        if(citiesLocals.find(cities[i]) == citiesLocals.end()) {
            vector<int>currentAreaVector;
            currentAreaVector.push_back(totalArea[i]);
            citiesLocals.insert(pair<string,vector<int>>(cities[i], currentAreaVector));
        } else {
            citiesLocals.at(cities[i]).push_back(totalArea[i]);

        }
    }

    int maxDiffLocals = 0, minDiffLocals = 1000, sameLocalsCounter, diffLocals;
    string maxCity, minCity;
    for(auto locals : citiesLocals) {
        cout << locals.second.size() << endl;
        for(int i=0; i<locals.second.size() - 1; i++) {
            sameLocalsCounter = 1;
            for(int j=i + 1; j<locals.second.size(); j++) {
                if(locals.second[i] == locals.second[j]) {
                    sameLocalsCounter++;
                }
            }
            cout << locals.second.size() << endl;
            diffLocals = locals.second.size() - sameLocalsCounter;
            if(diffLocals > maxDiffLocals) {
                maxDiffLocals = diffLocals;
                maxCity = locals.first;
            }
            if(diffLocals < minDiffLocals) {
                minDiffLocals = diffLocals;
                minCity = locals.first;
            }
        }
    }
    cout << maxCity << " " << maxDiffLocals << endl;
    cout << minCity << " " << minDiffLocals << endl;
    */
}
