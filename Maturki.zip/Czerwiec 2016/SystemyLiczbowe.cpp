#include<iostream>
#include<fstream>

using namespace std;

bool octagonal(string number) {

    for(int i = 0; i < number.size(); i++) {

        if(number[i] - 48 >= 8) {
            return false;
        }
    }
    return true;
}

bool quadrupleWithNoZeros(string number) {

    for(int i = 0; i < number.size(); i++) {

        if(number[i] - 48 >= 4 || number[i] - 48 == 0) {
            return false;
        }
    }
    return true;
}

bool evenBinary(string number) {

    for(int i = 0; i < number.size(); i++) {

        if(number[i] - 48 > 1) {
            return false;
        }
    }

    return ((number[number.size() - 1] - 48) % 2 == 0);
}

int exponentiation(int number, int exponent) {

    if(exponent == 0) {
        return 1;
    }
    int result = number;
    for(int i = 1; i < exponent; i++) {
        result *= number;
    }
    return result;
}

long long octagonalToDecimal(string number) {

    long long result = 0;
    for(int i = 0; i < number.size(); i++) {
        result += (number.at(number.size() - 1 - i) - 48)* exponentiation(8, i);
    }

    return result;
}


int main() {


    ifstream data;
    data.open("liczby.txt");

    ofstream out;

    int size = 999;
    string *numberCodes = new string[size];


    int octagonals = 0, quadrupleWithoutZeros = 0, evenBinaries = 0;

    long long octagonalsSum = 0;

    for(int i = 0; i < size; i++) {
        data >> numberCodes[i];

        if(octagonal(numberCodes[i])) {
            octagonalsSum += octagonalToDecimal(numberCodes[i]);
            octagonals++;
        }

        if(quadrupleWithNoZeros(numberCodes[i])) {
            quadrupleWithoutZeros++;
        }

        if(evenBinary(numberCodes[i])) {
            evenBinaries++;
        }

    }

    out.open("wyniki_6_1.txt");
    cout << "6.1) " << octagonals << endl;
    out << "6.1) " << octagonals << endl;
    out.close();

    out.open("wyniki_6_2.txt");
    cout << "6.2) " << quadrupleWithoutZeros << endl;
    out << "6.2) " << quadrupleWithoutZeros << endl;
    out.close();

    out.open("wyniki_6_3.txt");
    cout << "6.3) " << evenBinaries << endl;
    out << "6.3) " << evenBinaries << endl;
    out.close();

    out.open("wyniki_6_4.txt");
    cout << "6.4) " << octagonalsSum << endl;
    out << "6.4) " << octagonalsSum << endl;
    out.close();
}
