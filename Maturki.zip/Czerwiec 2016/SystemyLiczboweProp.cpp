#include<iostream>
#include<fstream>

using namespace std;

bool octagonal(string number) {

    return(number.at(number.size() - 1) == '8');
}

bool quadrupleWithNoZeros(string number) {

    if(number.at(number.size() - 1) == '4') {

        for(int i = 0; i < number.size() - 1; i++) {

            if(number[i] - 48 == 0) {
                return false;
            }
        }
        return true;
    }
    else {
        return false;
    }
}

bool evenBinary(string number) {

    return (number.at(number.size() - 2) - 48 % 2 == '0' &&
            number.at(number.size() - 1) == '2');
}

int exponentiation(int number, int exponent) {

    if(exponent == 0) {
        return 1;
    }
    int result = number;
    for(int i = 1; i < exponent; i++) {
        result *= number;
    }
    return result;
}

long long octagonalToDecimal(string number) {

    long long result = 0;
    for(int i = 0; i < number.size() - 1; i++) {
        result += (number.at(number.size() - 1 - 1 - i) - 48)* exponentiation(8, i);
    }

    return result;
}

long long toDecimal(string number) {

    int system = number[number.size() - 1] - 48;
    long long result = 0;

    for(int i = 0; i < number.size() - 1; i++) {

        result += (number.at(number.size() - 1 - 1 - i) - 48) * exponentiation(system, i);

    }

    return result;
}


int main() {

    ifstream data;
    data.open("liczby.txt");

    ofstream out;

    int size = 999;
    string *numberCodes = new string[size];


    int octagonals = 0, quadrupleWithoutZeros = 0, evenBinaries = 0;

    long long octagonalsSum = 0;

    string lowestCode;
    string biggestCode;
    long long biggestNumber = 0;
    long long lowestNumber = 999999;
    int currentValue;

    for(int i = 0; i < size; i++) {
        data >> numberCodes[i];

        if(octagonal(numberCodes[i])) {
            octagonalsSum += octagonalToDecimal(numberCodes[i]);
            octagonals++;
        }

        if(quadrupleWithNoZeros(numberCodes[i])) {
            quadrupleWithoutZeros++;
        }

        if(evenBinary(numberCodes[i])) {
            evenBinaries++;
        }

        currentValue = toDecimal(numberCodes[i]);
        if(currentValue > biggestNumber) {

            biggestNumber = currentValue;
            biggestCode = numberCodes[i];
        }
        if(currentValue < lowestNumber) {
            lowestNumber = currentValue;
            lowestCode = numberCodes[i];
        }
    }

    out.open("wyniki_6_1.txt");
    cout << "6.1) " << octagonals << endl;
    out << "6.1) " << octagonals << endl;
    out.close();

    out.open("wyniki_6_2.txt");
    cout << "6.2) " << quadrupleWithoutZeros << endl;
    out << "6.2) " << quadrupleWithoutZeros << endl;
    out.close();

    out.open("wyniki_6_3.txt");
    cout << "6.3) " << evenBinaries << endl;
    out << "6.3) " << evenBinaries << endl;
    out.close();

    out.open("wyniki_6_4.txt");
    cout << "6.4) " << octagonalsSum << endl;
    out << "6.4) " << octagonalsSum << endl;
    out.close();

    out.open("wyniki_6_5.txt");
    cout << "6.5)\n" << biggestCode << " " << biggestNumber << endl;
    cout << lowestCode << " " << lowestNumber << endl;
    out << "6.5)\n" << octagonalsSum << endl;
    out << lowestCode << " " << lowestNumber << endl;
    out.close();

    delete [] numberCodes;
}
